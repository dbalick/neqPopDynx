#!/bin/bash


#########################################################
###   RUN neqPopDynx_v1.5

##_______________________________________________________#
#   EXPONENTIAL simulations for various params
##_______________________________________________________#

## ONLY RECORDING MOMENTS AND CUMULANTS HERE!!!

INITSIZE=100
LEN=100000
## change this as needed for growth rate
GEN=2000
MU=1e-8
MUB=1e-10
DEMOG="exponential"
BURN=0
PRINT=10                     ### note this should be set to 1 for G>=1e-2
INITCOND="delta"
INITCOUNT=1
GROWTH=0.001

arrSELECTION=("-0.3162" "-0.1" "-0.01"  "-0.001" "-0.0001" "-0.00001")

arrRUNNUMBER=(1 2 3)

#####  --append will create a masterfile if one does not exist, and append otherwise
for RUN in "${arrRUNNUMBER[@]}";
do
for SHET in "${arrSELECTION[@]}";
do
python neqPopDynx_v1.5.0.py --initpopsize ${INITSIZE} -L ${LEN} --generations ${GEN} --mu ${MU} --mub ${MUB} --burnin ${BURN} -d ${DEMOG} --growth ${GROWTH} --initcond ${INITCOND} --initcount ${INITCOUNT} --shet ${SHET} --run ${RUN} --printgen ${PRINT} --moments --cumulants
done;
done;



printf "\n\n\nAll done. Enjoy!\n\n\n"
