#!/bin/bash


#########################################################
###   RUN neqPopDynx

##_______________________________________________________#
#   OSCILLATING simulations for various params
##_______________________________________________________#

## ONLY RECORDING MOMENTS AND CUMULANTS HERE!!!

INITSIZE=10000
LEN=100000
GEN=100000
MU=1e-8
MUB=1e-10
DEMOG="oscillating"
BURN=0
PRINT=10
INITCOND="delta"
INITCOUNT=1
## SPECIFY NMIN
NMIN="1000"
## SPECIFY PERIOD
PERIOD="10000"

arrSELECTION=("-0.3162" "-0.1" "-0.01"  "-0.001" "-0.0001" "-0.00001")

arrRUNNUMBER=(1 2 3)

#####  --append will create a masterfile if one does not exist, and append otherwise
for RUN in "${arrRUNNUMBER[@]}";
do
for SHET in "${arrSELECTION[@]}";
do
python neqPopDynx_v1.5.0.py --initpopsize ${INITSIZE} -L ${LEN} --generations ${GEN} --mu ${MU} --mub ${MUB} --burnin ${BURN} -d ${DEMOG} --initcond ${INITCOND} --initcount ${INITCOUNT} --shet ${SHET} --run ${RUN} --printgen ${PRINT} --Nmin ${NMIN} --period ${PERIOD} --moments --cumulants
done;
done;



printf "\n\n\nAll done. Enjoy!\n\n\n"
